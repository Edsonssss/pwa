import type { NextConfig } from "next";

/**
 * Два режима сборки:
 *  - по умолчанию — обычный dev/standalone для локальной разработки;
 *  - PAGES_BUILD=1 — статический экспорт для GitHub Pages (basePath = /pwa,
 *    т.е. имя репозитория Edsonssss/pwa).
 */
const isPages = process.env.PAGES_BUILD === "1";
const BASE = isPages ? "/pwa" : "";

const nextConfig: NextConfig = {
  ...(isPages
    ? {
        output: "export" as const,
        basePath: BASE,
        trailingSlash: true,
        images: { unoptimized: true },
      }
    : { output: "standalone" as const }),
  env: {
    NEXT_PUBLIC_BASE_PATH: BASE,
    NEXT_PUBLIC_SW_PATH: `${BASE}/sw.js`,
    NEXT_PUBLIC_MANIFEST_PATH: `${BASE}/manifest.webmanifest`,
  },
  typescript: {
    ignoreBuildErrors: true,
  },
  reactStrictMode: false,
};

export default nextConfig;
