# Ежедневник — PWA для iOS 📱✅

Личный ежедневник с напоминаниями и меню проектов, оформленный как Progressive Web App.
Работает **полностью без сервера**: сайт публикуется на GitHub Pages как статика, а все
данные хранятся на устройстве в localStorage (JSON). Устанавливается на iPhone/iPad с
главного экрана и работает как отдельное приложение, в том числе офлайн.

**Живой адрес:** https://edsonssss.github.io/pwa/

## Возможности

- **Ежедневник** — лента дней с автопрокруткой к сегодняшнему, напоминания с датой,
  временем, приоритетом и заметкой; создание, редактирование, удаление (с подтверждением),
  отметка «выполнено»; разделы «В работе» / «Выполнено», метка «Просрочено», прогресс дня,
  режимы «День» и «Все дела» с группировкой «Сегодня / Завтра / Вчера».
- **Меню «Проекты»** — карточки ссылок на другие страницы и проекты: emoji-значок,
  название, описание, открытие в новой вкладке; добавление, редактирование, удаление.
- **Несколько пользователей** — профили с именем и цветом, опциональный 4-значный PIN-код
  (хеш SHA-256 + соль через Web Crypto, PIN никогда не хранится открыто), изоляция данных
  по профилю, быстрое переключение, автовход на устройстве.
- **Данные на устройстве** — всё хранится в localStorage браузера/установленного PWA.
  В настройках есть **Экспорт JSON** (резервная копия файлом) и **Импорт JSON** (перенос
  данных на новое устройство или другому человеку).
- **Офлайн и PWA** — service worker: страницы network-first с офлайн-фолбэком, иконки
  cache-first; манифест с maskable-иконкой, safe-area для «челки» и жеста «домой».

## Как это работает без сервера

Приложение — статический экспорт Next.js (`output: "export"`). Хранилище `src/lib/local-store.ts`
читает и пишет единый JSON-ключ `localStorage["planner.db.v1"]` со структурой:

```json
{
  "users":     [{ "id", "name", "color", "pinSalt", "pinHash", "createdAt" }],
  "reminders": [{ "id", "userId", "title", "note", "date", "time", "priority", "completed", "…dates" }],
  "links":     [{ "id", "userId", "title", "url", "description", "icon", "createdAt" }]
}
```

Все операции с данными проходят через очередь (`enqueue`), чтобы быстрые нажатия не
затирали друг друга. Интерфейс `src/lib/api-client.ts` сохранён прежним, поэтому
компоненты не зависят от того, где лежат данные.

> Важно: данные привязаны к браузеру устройства. Очистка данных Safari удалит их —
> делайте экспорт JSON время от времени.

## Деплой на GitHub Pages

Готовая статическая сборка лежит в папке **`docs/`** ветки `main` — GitHub Pages умеет
раздавать её напрямую, без CI. Включите один раз:

1. **Settings → Pages → Build and deployment → Source: Deploy from a branch**.
2. Branch: **`main`**, папка: **`/docs`** → Save.
3. Через минуту сайт откроется на `https://<логин>.github.io/pwa/`.

Пересборка `docs/` после изменений кода:

```bash
bun run deploy:docs   # сборка + обновление docs/
```

**Альтернатива — автодеплой через GitHub Actions** (`.github/workflows/deploy.yml`
в проекте): Source → GitHub Actions, и при каждом push в `main` сайт пересобирается сам.
Для пуша workflow-файла токен должен иметь разрешение **Workflows**; имя репозитория
(`pwa`) захардкожено как basePath — при переименовании репозитория поменяйте `BASE`
в `next.config.ts`. Используйте один из двух способов: если включён Actions, выберите
Source: GitHub Actions.

## Локальная разработка

```bash
bun install
bun run dev        # http://localhost:3000 — обычный dev-режим
bun run lint       # ESLint
PAGES_BUILD=1 bun run build   # статический экспорт в out/ (как на Pages)
```

Локальный предпросмотр экспорта с basePath (эмуляция GitHub Pages):

```bash
mkdir -p /tmp/pages/pwa && cp -r out/. /tmp/pages/pwa/ && cd /tmp/pages && python3 -m http.server 8000
# открыть http://localhost:8000/pwa/
```

## Установка на iPhone / iPad

1. Откройте https://edsonssss.github.io/pwa/ в **Safari**.
2. Кнопка «Поделиться» → **«На экран „Домой“»** → «Добавить».
3. Иконка на главном экране — приложение запускается без адресной строки и работает офлайн.

## Структура проекта

```
src/
  app/                 # страница, layout, manifest.webmanifest
  components/          # user-gate, planner-view, projects-view, settings-view, pin-pad…
  lib/
    local-store.ts     # клиентское JSON-хранилище (localStorage + Web Crypto)
    api-client.ts      # единый интерфейс доступа к данным
    types.ts           # PublicUser, Reminder, ProjectLink
  hooks/use-pwa.ts     # регистрация service worker, standalone-режим
public/
  sw.js                # service worker (пути от scope: работает и в /, и в /pwa/)
  icons/               # иконки PWA (генерация: python3 scripts/gen_icons.py)
.github/workflows/deploy.yml  # автодеплой на GitHub Pages
```
